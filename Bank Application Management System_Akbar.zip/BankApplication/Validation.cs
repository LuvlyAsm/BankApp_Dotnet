using System;

namespace BankApp{

public class Validation{

    //User Inputs
     string name="",password="";   
     string amount="";                  

     //Validating User Details
    public void validate(){
        
        //List for Storing Existing User Records
        List<Bank> accounts=new List<Bank>();
        Bank customer1=new Bank("ASM","Password@123",1200);
        Bank customer2=new Bank("Kavi","Password@1234",1100);
        Bank customer3=new Bank("Ravi","Password@123456",1000);
        Bank customer4=new Bank("Mahesh","Password@123456",1000);
        accounts.Add(customer1);
        accounts.Add(customer2);
        accounts.Add(customer3);
        accounts.Add(customer4);

        
        Console.WriteLine("\n------------Welcome to our ABC Bank-------------\nEnter to continue....\n1.LogIn\n2.Signup");
         Console.WriteLine("-------------------------------------------------");
        string userChoise = Console.ReadLine();      //user input for LogIn or SignUp
        Console.WriteLine("-------------------------------------------------");
        //LogIn 
        if(userChoise.Equals("1"))
        {
            //Taking input from user
            try{
                Console.WriteLine("Enter Username");
            name=Console.ReadLine();
                 Console.WriteLine("Enter Password");
            password=Console.ReadLine();
                 Console.WriteLine("-------------------------------------------------");

            }
            catch(Exception exception){
                    Console.WriteLine("-------------------------------------------------");
                    Console.WriteLine(exception);
                    validate();
                  Console.WriteLine("-------------------------------------------------");
            }

            
            //LogIn Validation for Checking Users in the List

            int count=0;                   
            foreach(Bank accountDetails in accounts){
               if(name.Equals(accountDetails.getName())&&password.Equals(accountDetails.getPassword())){
                Console.WriteLine("Logged In Successfully");
                count=1;
                   accountDetails.operation();}
               }

               if(count==0)
               {
                   Console.WriteLine("-------------------------------------------------");
                   Console.WriteLine("Enter Valid Details");
                   Console.WriteLine("-------------------------------------------------");
                   validate();
                 }
        }

        //SignUp 

        else if(userChoise.Equals("2")){
         Console.WriteLine("-------------------------------------------------");
            //Taking input from user
        try{
        Console.WriteLine("Enter Username");
            name=Console.ReadLine();
        
        Console.WriteLine("Enter Password");
             password=Console.ReadLine();
        
        Console.WriteLine("Enter amount to deposit");
            amount=Console.ReadLine();

            
            Bank newUser=new Bank(name,password,int.Parse(amount));
            accounts.Add(newUser);
            newUser.operation();
            Console.WriteLine("-------------------------------------------------");
        }
        
        catch(Exception exception){
            Console.WriteLine("-------------------------------------------------");
            Console.WriteLine("\nEnter Valid Details\n");
            Console.WriteLine("-------------------------------------------------");
            validate();
        }
            
            
        }

        else{
            Console.WriteLine("-------------------------------------------------");
        Console.WriteLine("\nInput Invalid\n");
        Console.WriteLine("-------------------------------------------------");
        validate();
        }
    }



}


}