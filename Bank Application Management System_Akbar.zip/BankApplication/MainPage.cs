﻿/*
		 * Title : Bank Application Management System
		 * Author : Akbar Syed
		 * Created On : 07-JUN-2022 
		 * Updated on : 09-JUN-2022
		 * Reviewed by : Sabapathi Shanmugam
		 * Reviewed at : 08-JUN-2022

		 */

using System;

namespace BankApp;

internal class MainPage
{
    private static void Main(string[] args){
         Validation validation=new Validation();
         validation.validate();    }
     
}
    