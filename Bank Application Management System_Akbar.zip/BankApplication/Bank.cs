using System;

namespace BankApp;

public class Bank {

    //User Variables
    private string name,password;
    int amount;

    string depositAmount="",withdrawAmount="";

    //Default constructor
   public Bank(){}

    //constructor to assign user datas
   public Bank(string name,string password,int amount){
        this.name=name;
        this.password=password;
        this.amount=amount;}

    //Encapsulation for getting username and password which is already present in the accounts
       public string getName(){return name;}
       public string getPassword(){return password;}

   //operations to be performed by user
    public void operation(){
        Console.WriteLine("-------------------------------------------------");
        Console.WriteLine("Enter to Continue\n1.Deposit\n2.Withdraw\n3.Balance\n4.Transaction History\n5.LogOut\n");
      Console.WriteLine("-------------------------------------------------");
        string choise=Console.ReadLine();
        switch(choise){
            case "1":deposit();
                break;
            case "2":withdraw();
                break;
            case "3":balance();
                break;
            case "4":transaction();
                break;
            case "5":logOut();
                break;
            default:
                Console.WriteLine("Invalid Input");
                operation();
                break;
        }
    }

//List Transaction History
    List<String> transactionHistory=new List<String>();
    
 //Deposit money to bank account
    void deposit(){
        Console.WriteLine("Enter a Amount to be Deposit...:");
         depositAmount=Console.ReadLine();
        amount=amount+int.Parse(depositAmount.ToString());
        Console.WriteLine("-------------------------------------------------");
        //Updating Transaction History
        Console.WriteLine("After Deposit Account Balance is :"+amount);
        transactionHistory.Add("+"+depositAmount);
        Console.WriteLine("-------------------------------------------------");
        operation();
    }

//Withdraw money from bank account
    void withdraw(){
         Console.WriteLine("-------------------------------------------------");
        Console.WriteLine("Enter How Much You Want to Withdraw...");
        withdrawAmount=Console.ReadLine();

       //Checking Bank Balance > Withdraw amount or not
        if(int.Parse(withdrawAmount.ToString())<=amount){
            amount=amount-int.Parse(withdrawAmount.ToString());
            Console.WriteLine("-------------------------------------------------");
            //Updating Transaction History
            Console.WriteLine("Your Account Balance is : "+amount);
            transactionHistory.Add("-"+withdrawAmount);
            Console.WriteLine("-------------------------------------------------");
        }
        else{
            Console.WriteLine("-------------------------------------------------");
             Console.WriteLine("Insufficient Balance");
             Console.WriteLine("-------------------------------------------------");
             Console.WriteLine("Your Account Balance is : "+amount);
             Console.WriteLine("-------------------------------------------------");
        }
     
        operation();
    }
//Check Bank Balance
    void balance(){
        
        Console.WriteLine("Your Account Balance is : "+amount);
        Console.WriteLine("-------------------------------------------------");
        operation();
    }

//View Transaction history
    void transaction(){
       
        Console.WriteLine("Your Transaction History is :");
        for(int i=0;i<transactionHistory.Count;i++){
            Console.WriteLine(transactionHistory[i]);
        }
      Console.WriteLine("-------------------------------------------------");
        operation();
    }

// User LogOut 
    void logOut(){
        Console.WriteLine("Successfully Logged Out :)");
        Console.WriteLine("-------------------------------------------------");
        Validation validation=new Validation();
        validation.validate();

    }
}